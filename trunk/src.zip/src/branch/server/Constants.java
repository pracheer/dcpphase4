package branch.server;

public class Constants {

	public static final String COMMENT_START = "#";

}
